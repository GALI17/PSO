package prepare;

import java.io.File;

public class CreatFiles_1 {
	public static void main(String[] args){
		int N = 100;
		for(int i = 0; i < N; i++){
			File inputdata0 = new File("E:\\PSOlab\\30-26\\hc\\hc" + (i+1));
			File inputdata1 = new File("E:\\PSOlab\\30-26\\inp\\inp" + (i+1));
			File inputdata2 = new File("E:\\PSOlab\\30-26\\ins\\ins" + (i+1));
			inputdata0.mkdir();
			inputdata1.mkdir();
			inputdata2.mkdir();
		}
		System.out.println("done~");
	}
}
