//�Ѳ��Գɹ�
package myPso;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Pso_p2 {
	public static int[][] matrix;
									
	private final int step = 2000; 
	private final int PosNum = 10; 
	private final double ws = 0.9;
	private final double we = 0.4;
	private final double c1 = 2;
	private final double c2 = 2;

	private static String final_g;
	private static double final_value;
	private static int k;

	private static int g_best; 
	private static int g_value_best;

	private int p_best[] = new int[PosNum];
	private int[] p_value_best = new int[PosNum];

	private int[] p_v = new int[PosNum];
	private int[] p_pos = new int[PosNum];
	private int[] p_value = new int[PosNum];

	private Random random = new Random();
	private static HashSet<Integer> single = new HashSet<>();
	private static ArrayList<Integer> newSingle = new ArrayList<>();

	
	static List<List<String>> totalRes = new ArrayList<>();
	static List<String> cur11 = new ArrayList<>();
	static List<String> cur22 = new ArrayList<>();
	public static int FFF;

	public static void main(String args[]) throws Exception {
		for (int k1 = 1; k1 <= 100; k1++) {
			totalRes.clear();
			for (int k2 = 1; k2 <= 15; k2++) {
				System.out.println(k2);
				//�����һ�ν��
				cur11 = new ArrayList<>();
				cur22= new ArrayList<>();
				
				Pso_p2 pos = new Pso_p2();
				pos.readData("E:\\PSOlab\\30-26\\inp\\inp" + k1 + "\\inp" + k2 + ".txt");

				int tag1 = findTag1();
				k = tag1 * 40 / 100;

				for (int j = 0; j < matrix[0].length - 1; j++) {
					int score1 = 0;
					for (int i = 0; i < matrix.length; i++) {
						if (matrix[i][j] == 1) {
							score1 += 1;
						}
					}
					if (score1 >= k) {
						single.add(j);
					}

				}
//				System.out.println(single);
//				System.out.println(single.size());
				
				if (single.size() > 0) {
					pos.beginFind();
				}
				
				totalRes.add(cur11);
				totalRes.add(cur22);
			}
			System.out.println(totalRes);
			String road = "E:\\PSOlab\\30-26\\res\\p\\pres" + k1 +".txt";
			outPData(totalRes,road);
		}

	}


	private static void outPData(List<List<String>> totalRes2, String road) throws IOException {
		File f = new File(road);
		BufferedWriter bw = new BufferedWriter(new FileWriter(f));
		for(int i = 0; i < totalRes2.size(); i++){
			ArrayList<String> temp = new ArrayList<>(totalRes2.get(i));
			String s = "";
			for(String str:temp){
				s = str + "";
			}
			bw.write(s.trim());
			bw.newLine();
		}
		bw.close();
	}


	public void beginFind() {
		Iterator<Integer> it = single.iterator();
		while (it.hasNext()) {
			newSingle.add(it.next());
		}
		String res = "";
		String sscore = "";

		for (int i = 0; i < 20; i++) {
			Pso_p2 pos = new Pso_p2();

			final_g = " ";
			final_value = 0;
			pos.Initialize();
			pos.Search();
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;

			FFF = 1;

			if (final_value >= k && FFF == 1) {
				if (newSingle.size() > 0) {
					expand2();
				}
				String[] cur = final_g.split(" ");
				if (cur.length == 1) {
					if (isFalse(cur)) {
						return;
					}
				}

				res += final_g.trim() + " -2 ";
				sscore += final_value + " ";

				// System.out.println(final_value);
				// System.out.println(final_g);

			} else {
				// System.out.println("�޷������������");
			}

			String[] g = final_g.split(" ");
			for (int q = 0; q < g.length; q++) {
				int temp = Integer.valueOf(g[q]);
				for (int k = 0; k < newSingle.size(); k++) {
					if (newSingle.get(k) == temp) {
						newSingle.remove(k);
						continue;
					}
				}
			}

		}
		cur11.add(sscore);
		cur22.add(res);
		System.out.println(sscore);
		System.out.println(res);
	}

	private static int findTag1() {
		int res = 0;
		for (int i = 0; i < matrix.length; i++) {
			if (matrix[i][matrix[0].length - 1] == 1) {
				res += 1;
			}
		}
		return res;
	}

	private boolean isFalse(String[] cur) {
		int temp = Integer.valueOf(cur[0]);
		for (int i = 0; i < matrix.length; i++) {
			if (matrix[i][temp] == 1 && matrix[i][matrix[0].length - 1] == 0) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ���У�matrix �� k����ʼ��� g_best�� g_value_best
	 * 
	 * save�� ��ʼ��� final_g final_value
	 * 
	 * �����£���������ֵ�� g_best�� g_value_best
	 * 
	 * @param flag
	 */
	private static void expand2() {
		Pso_p2 pos = new Pso_p2();
		pos.Initialize();
		pos.Search();
		if (FFF == 1 && g_value_best >= k && g_value_best >= final_value) {
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;
			if (newSingle.size() > 0) {
				expand3();
			}
		} else if (FFF == 1 && g_value_best >= k && g_value_best < final_value) {
			for (int i = 0; i < matrix.length; i++) {
				char[] m = final_g.toCharArray();
				int n = m[0] - '0';
				if (matrix[i][n] == 1 && matrix[i][matrix[0].length - 1] == 0) {
					final_g = newSingle.get(g_best) + " " + final_g;
					final_value = g_value_best;
					if (newSingle.size() > 0) {
						expand3();
						if (FFF == 0)
							return;
					}
				}
			}
		} else {
			FFF = 0;
		}

		if (FFF == 0)
			return;
	}

	private static void expand3() {
		Pso_p2 pos = new Pso_p2();
		pos.Initialize();
		pos.Search();
		if (FFF == 1 && g_value_best >= k && g_value_best >= final_value) {
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;
			if (newSingle.size() > 0) {
				expand4();
			}
		} else if (FFF == 1 && g_value_best >= k && g_value_best < final_value) {
			for (int i = 0; i < matrix.length; i++) {
				char[] m = final_g.toCharArray();
				int n = m[0] - '0';
				if (matrix[i][n] == 1 && matrix[i][matrix[0].length - 1] == 0) {
					final_g = newSingle.get(g_best) + " " + final_g;
					final_value = g_value_best;
					if (newSingle.size() > 0) {
						expand4();
						if (FFF == 0)
							return;
					}
				}
			}
		} else {
			FFF = 0;
		}
		if (FFF == 0)
			return;
	}

	private static void expand4() {
		Pso_p2 pos = new Pso_p2();
		pos.Initialize();
		pos.Search();
		if (FFF == 1 && g_value_best >= k && g_value_best >= final_value) {
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;
			if (newSingle.size() > 0) {
				expand5();
			}
		} else if (FFF == 1 && g_value_best >= k && g_value_best < final_value) {
			for (int i = 0; i < matrix.length; i++) {
				char[] m = final_g.toCharArray();
				int n = m[0] - '0';
				if (matrix[i][n] == 1 && matrix[i][matrix[0].length - 1] == 0) {
					final_g = newSingle.get(g_best) + " " + final_g;
					final_value = g_value_best;
					if (newSingle.size() > 0) {
						expand5();
						if (FFF == 0)
							return;
					}
				}
			}
		} else {
			FFF = 0;
		}
		if (FFF == 0)
			return;
	}

	private static void expand5() {
		Pso_p2 pos = new Pso_p2();
		pos.Initialize();
		pos.Search();
		if (FFF == 1 && g_value_best >= k && g_value_best >= final_value) {
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;
			if (newSingle.size() > 0) {
				expand6();
			}
		} else if (FFF == 1 && g_value_best >= k && g_value_best < final_value) {
			for (int i = 0; i < matrix.length; i++) {
				char[] m = final_g.toCharArray();
				int n = m[0] - '0';
				if (matrix[i][n] == 1 && matrix[i][matrix[0].length - 1] == 0) {
					final_g = newSingle.get(g_best) + " " + final_g;
					final_value = g_value_best;
					if (newSingle.size() > 0) {
						expand6();
						if (FFF == 0)
							return;
					}
				}
			}
		} else {
			FFF = 0;
		}
		if (FFF == 0)
			return;

	}

	private static void expand6() {
		Pso_p2 pos = new Pso_p2();
		pos.Initialize();
		pos.Search();
		if (FFF == 1 && g_value_best >= k && g_value_best >= final_value) {
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;
			if (newSingle.size() > 0) {
				expand7();
			}
		} else if (FFF == 1 && g_value_best >= k && g_value_best < final_value) {
			for (int i = 0; i < matrix.length; i++) {
				char[] m = final_g.toCharArray();
				int n = m[0] - '0';
				if (matrix[i][n] == 1 && matrix[i][matrix[0].length - 1] == 0) {
					final_g = newSingle.get(g_best) + " " + final_g;
					final_value = g_value_best;
					if (newSingle.size() > 0) {
						expand7();
						if (FFF == 0)
							return;
					}
				}
			}
		} else {
			FFF = 0;
		}
		if (FFF == 0)
			return;
	}

	private static void expand7() {
		Pso_p2 pos = new Pso_p2();
		pos.Initialize();
		pos.Search();
		if (FFF == 1 && g_value_best >= k && g_value_best >= final_value) {
			final_g = newSingle.get(g_best) + " " + final_g;
			final_value = g_value_best;
			if (newSingle.size() > 0) {
			}
		} else if (FFF == 1 && g_value_best >= k && g_value_best < final_value) {
			for (int i = 0; i < matrix.length; i++) {
				char[] m = final_g.toCharArray();
				int n = m[0] - '0';
				if (matrix[i][n] == 1 && matrix[i][matrix[0].length - 1] == 0) {
					final_g = newSingle.get(g_best) + " " + final_g;
					final_value = g_value_best;
					if (newSingle.size() > 0) {
						if (FFF == 0)
							return;
					}
				}
			}
		} else {
			FFF = 0;
		}
		if (FFF == 0)
			return;

	}

	public void readData(String datarode) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(datarode));
		List<int[]> vecList = new ArrayList<int[]>();
		String contentLine = br.readLine();
		while (contentLine != null) {
			String[] items = contentLine.split(" ");
			int[] rowData = new int[items.length];
			for (int j = 0; j < items.length; j++) {
				rowData[j] = Integer.parseInt(items[j]);
			}
			vecList.add(rowData);
			contentLine = br.readLine();
		}
		matrix = new int[vecList.size()][];
		for (int i = 0; i < vecList.size(); i++) {
			matrix[i] = vecList.get(i);
		}
		br.close();
	}

	public void Initialize() {
		int posMax = newSingle.size() - 1;
		int posMin = 0;
		int select = posMax - posMin;


		for (int i = 0; i < PosNum; i++) {
			int[] g = final_gToInt(final_g);
			HashSet<Integer> set = new HashSet<>();
			for (int k = 0; k < g.length; k++) {
				set.add(g[k]);
			}

			p_pos[i] = (int) (posMin + Math.random() * select);
			while (set.contains(newSingle.get(p_pos[i]))) {
				p_pos[i] = (int) (posMin + Math.random() * select);
			}

			p_v[i] = (int) Math.random() * posMax;

			p_value[i] = function(p_pos[i], matrix, final_g);
			p_value_best[i] = p_value[i];
			p_best[i] = p_pos[i];
		}

		g_value_best = -1;
		for (int i = 0; i < PosNum; i++) {
			if (p_value_best[i] > g_value_best) {
				g_value_best = p_value_best[i];
				g_best = p_best[i];
			}
		}

	}

	public void Search() {
		boolean go_on = true;
		for (int j = 0; j < step && go_on == true; j++) 
		{
			double w = ws - (ws - we) * j / step;
			for (int i = 0; i < PosNum; i++) 
			{
				p_v[i] = (int) (w * p_v[i] + c1 * random.nextDouble() * (p_best[i] - p_pos[i])
						+ c2 * random.nextDouble() * (g_best - p_pos[i]));
				p_pos[i] = p_pos[i] + p_v[i];

				int posMax = newSingle.size() - 1;
				int posMin = 0;
				if (p_pos[i] > posMax)
					p_pos[i] = posMax;
				if (p_pos[i] < posMin)
					p_pos[i] = posMin;

				int[] g = final_gToInt(final_g);
				HashSet<Integer> set = new HashSet<>();
				for (int k = 0; k < g.length; k++) {
					set.add(g[k]);
				}
				if (set.contains(newSingle.get(p_pos[i]))) {
					continue;
				}

				int score = function(p_pos[i], matrix, final_g);

				if (score > p_value_best[i]) {
					p_best[i] = p_pos[i];
					p_value_best[i] = score;
				}
				if (score > g_value_best) {
					g_best = p_best[i];
					g_value_best = score;
				}
			}

			if (g_value_best >= k) {
				if (final_g == " ") {
					go_on = false;
				} else {
					int[] g = final_gToInt(final_g);
					HashSet<Integer> set = new HashSet<>();
					for (int k = 0; k < g.length; k++) {
						set.add(g[k]);
					}
					if (!set.contains(newSingle.get(g_best))) {
						go_on = false;
					}
				}
			}
		}
	}

	public int function(int p_pos, int[][] matrix, String final_g) {
		int real_p_pos = newSingle.get(p_pos);
		int c1 = 0;
		for (int i = 0; i < matrix.length; i++) {
			int k = matrix[0].length - 1;
			int d = matrix[i][k];
			int b = matrix[i][real_p_pos];
			if (final_g == " ") {
				if (b == 1 && d == 1)
					c1 += 1;
			} else {

				int[] g = final_gToInt(final_g);
				for (int j = 0; j < g.length; j++) {
					int m = g[j];
					b = b * matrix[i][m];
				}
				if (b == 1 && d == 1)
					c1 += 1;
			}
		}
		return c1;
	}

	private int[] final_gToInt(String final_g) {
		String[] items = final_g.split(" ");
		int[] g = new int[items.length];
		for (int j = 0; j < items.length; j++) {
			g[j] = Integer.parseInt(items[j]);
		}
		return g;
	}

	private void Search1() {
		boolean go_on = true;
		for (int j = 0; j < step && go_on == true; j++) 
		{
			double w = ws - (ws - we) * j / step;
			for (int i = 0; i < PosNum; i++) 
			{
				p_v[i] = (int) (w * p_v[i] + c1 * random.nextDouble() * (p_best[i] - p_pos[i])
						+ c2 * random.nextDouble() * (g_best - p_pos[i]));
				p_pos[i] = p_pos[i] + p_v[i];

				int posMax = matrix[0].length - 2;
				int posMin = 0;
				if (p_pos[i] > posMax)
					p_pos[i] = posMax;
				if (p_pos[i] < posMin)
					p_pos[i] = posMin;

				int score = function1(p_pos[i], matrix);

				if (score > p_value_best[i]) {
					p_best[i] = p_pos[i];
					p_value_best[i] = score;
				}
				if (score > g_value_best) {
					g_best = p_best[i];
					g_value_best = score;
				}

				if (g_value_best >= k)
					go_on = false;
			}
		}
	}

	private void Initialize1() {
		int posMax = matrix[0].length - 2;
		int posMin = 0;
		int select = posMax - posMin;
		for (int i = 0; i < PosNum; i++) {
			p_pos[i] = (int) (posMin + Math.random() * select);
			p_v[i] = (int) Math.random() * posMax;

			p_value[i] = function1(p_pos[i], matrix);
			p_value_best[i] = p_value[i];
			p_best[i] = p_pos[i];
		}

		g_value_best = -1;
		for (int i = 0; i < PosNum; i++) {
			if (p_value_best[i] > g_value_best) {
				g_value_best = p_value_best[i];
				g_best = p_best[i];
			}
		}
	}

	private int function1(int p_pos, int[][] matrix) {
		int c1 = 0;
		for (int i = 0; i < matrix.length; i++) {
			int k = matrix[0].length - 1;
			int d = matrix[i][k];
			int b = matrix[i][p_pos];
			if (b == 1 && d == 1)
				c1 += 1;
		}
		return c1;
	}
}